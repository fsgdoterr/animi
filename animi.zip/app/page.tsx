'use client'
import { useTheme } from "next-themes";

export default function Home() {
    const {theme, setTheme} = useTheme();
    return (
        <div>
            <button onClick={() => setTheme(theme === "light" ? "dark" : "light")}>
                change theme
            </button>
        </div>
    );
}
